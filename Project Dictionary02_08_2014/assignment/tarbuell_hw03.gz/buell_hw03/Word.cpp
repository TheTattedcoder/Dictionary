#include "Word.h"

Word::Word()
{
}

Word::Word(string wordString)
{
}

Word::~Word()
{
}

string Word::getOriginal()
{
} // string Word::getOriginal()

bool Word::isAStopWord()
{
} // bool Word::isAStopWord()

void Word::setAsStopWord()
{
} // void Word::setAsStopWord()

void Word::bumpCount()
{
} // void Word::bumpCount()

string Word::toString()
{
} // string Word::toString()

