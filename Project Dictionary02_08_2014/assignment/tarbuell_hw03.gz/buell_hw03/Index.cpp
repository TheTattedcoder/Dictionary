#include "Index.h"

Index::Index()
{
}

Index::~Index()
{
}

void Index::processTheWords(Stoplist stoplist)
{
} // void Index::processTheWords()

void Index::readData(Scanner& inScanner)
{
} // void Index::readData(Scanner& inScanner)

string Index::toString()
{
  return "zork";
} // string Index::toString()
