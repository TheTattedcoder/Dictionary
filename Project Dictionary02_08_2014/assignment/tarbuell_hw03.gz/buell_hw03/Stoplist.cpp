#include "Stoplist.h"

Stoplist::Stoplist()
{
}

Stoplist::~Stoplist()
{
}

bool Stoplist::isInStoplist(string word)
{
}

void Stoplist::readData(Scanner& stoplistScanner)
{
}

string Stoplist::toString()
{
}
